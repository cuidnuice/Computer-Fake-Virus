1. github(깃허브)에서 "cuidnuice"라는 유저가 만든 "FakeVirus.exe"를 다운로드 한것인지 확인해주세요
2. 만약 아니라면 즉시 삭제 후 절대로 실행 하지 마세요.
3. 만약 위의 경고를 전부 무시하고 제작자의 파일이 아닌 다른 파일을 실행, 그로인해서 만약 컴퓨터의 물리적 또는 파일에 손상이 가는 경우 제작자는 "절대로" 책임지지 않습니다.
4. 제대로 즐기시려면 관리자 권환으로 실핼해주세요.

1. Please confirm that you downloaded "FakeVirus.exe" created by a user named "cuidnuice" on github (github)
2. If not, delete it immediately and never run it.
3. If you ignore all of the above warnings and run a file other than the creator's, the creator will "never" be responsible for any damage to the physical or file on your computer.
4. If you want to enjoy it properly, please sign it as administrator.